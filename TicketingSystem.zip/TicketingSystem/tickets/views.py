from django.contrib.auth import authenticate, login, logout
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Ticket, Assignment, Activity, User, Notification, Customer
from .forms import TicketForm, AssignmentForm, UpdateStatusForm, ActivityForm, CustomerRegistrationForm, \
    CustomerLoginForm
from django.core.mail import send_mail
from django.conf import settings
from .utils import send_notification
from django.core.exceptions import PermissionDenied

def register(request):
    if request.method == "POST":
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("login")
    else:
        form = CustomerRegistrationForm()
    return render(request, "tickets/register.html", {"form": form})

def login_view(request):
    if request.method == "POST":
        form = CustomerLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get("email")
            password = form.cleaned_data.get("password")
            user = authenticate(request, email=email, password=password)
            if user is not None:
                login(request, user)
                return redirect("ticket_list")
    else:
        form = CustomerLoginForm()
    return render(request, "tickets/login.html", {"form": form})

def logout_view(request):
    logout(request)
    return redirect("login")

@login_required
def ticket_list(request):
    breakpoint()
    user = get_object_or_404(Customer, email=request.user.email)
    tickets_with_assigned_users = Ticket.objects.filter(assigned_customer=user).all()
    print(tickets_with_assigned_users)  # This should show tickets with at least one user in assigned_to
    # Retrieves tickets where user is assigned
    return render(request, "tickets/ticket_list.html", {"tickets": tickets_with_assigned_users})

def all_create_ticket_list(request):
    tickets = Ticket.objects.all()  # Retrieve all tickets
    return render(request, 'tickets/ticket_list.html', {'tickets': tickets})

def ticket_detail(request, ticket_id):
    ticket = get_object_or_404(Ticket, id=ticket_id)
    return render(request, 'tickets/ticket_detail.html', {'ticket': ticket})

@login_required
def create_ticket(request):
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.creator = request.user
            ticket.save()
            messages.success(request, 'Ticket created successfully.')
            return redirect('all_create_ticket_list')
    else:
        form = TicketForm()
    return render(request, 'tickets/create_ticket.html', {'form': form})

@login_required
def assign_ticket(request, ticket_id):
    ticket = get_object_or_404(Ticket, id=ticket_id)
    available_users = Customer.objects.exclude(id__in=ticket.assignments.values_list('assigned_user', flat=True))
    if request.method == 'POST':
        form = AssignmentForm(request.POST, available_users=available_users)
        if form.is_valid():
            assigned_user = form.cleaned_data['assigned_user']
            Assignment.objects.create(ticket=ticket, assigned_user=assigned_user)
            Ticket.objects.create(assigned_customer=assigned_user)
            # Send notification (email) to assigned user
            Notification.objects.create(
                ticket=ticket,
                recipient=assigned_user,
                message=f"You have been assigned to the ticket: {ticket.title}"
            )
            # send_mail(
            #     'Ticket Assignment Notification',
            #     f'You have been assigned to the ticket: {ticket.title}',
            #     settings.DEFAULT_FROM_EMAIL,
            #     [assigned_user.email]
            # )
            message = f"You have been assigned to the ticket: {ticket.title}"
            send_notification(ticket, assigned_user, message)
            messages.success(request, f'{assigned_user} has been assigned to the ticket.')
            return redirect('ticket_detail', ticket_id=ticket.id)
    else:
        form = AssignmentForm(available_users=available_users)
    return render(request, 'tickets/assign_ticket.html', {'form': form, 'ticket': ticket})


@login_required
def update_status(request, ticket_id):
    ticket = get_object_or_404(Ticket, id=ticket_id)

    # Check if the user has permission to update the ticket
    if request.user != ticket.creator:
        # Allow admins with `can_update_any_ticket` permission to update any ticket
        if not request.user.has_perm('tickets.can_update_any_ticket'):
            raise PermissionDenied("You do not have permission to update this ticket.")
    else:
        # Allow the ticket creator to update only their own ticket if they have `can_update_own_ticket` permission
        if not request.user.has_perm('tickets.can_update_own_ticket'):
            raise PermissionDenied("You do not have permission to update your ticket.")

    # Proceed with updating the status
    if request.method == 'POST':
        form = UpdateStatusForm(request.POST, instance=ticket)
        if form.is_valid():
            ticket = form.save()
            Activity.objects.create(
                ticket=ticket,
                action='status_change',
                status=ticket.status,
                performed_by=request.user
            )

            # Notify creator and assignees
            for user in [ticket.creator] + list(ticket.assignments.values_list('assigned_user', flat=True)):
                message = f"Status of ticket '{ticket.title}' changed to {ticket.status}."
                send_notification(ticket, user, message)

            messages.success(request, 'Ticket status updated.')
            return redirect('ticket_detail', ticket_id=ticket.id)
    else:
        form = UpdateStatusForm(instance=ticket)
    return render(request, 'tickets/update_status.html', {'form': form, 'ticket': ticket})


@login_required
def add_activity(request, ticket_id):
    ticket = get_object_or_404(Ticket, id=ticket_id)
    if request.method == 'POST':
        form = ActivityForm(request.POST)
        if form.is_valid():
            activity = form.save(commit=False)
            activity.ticket = ticket
            activity.performed_by = request.user
            activity.action = 'comment'
            activity.save()
            # Notify creator and assignees
            for user in [ticket.creator] + list(ticket.assignments.values_list('assigned_user', flat=True)):
                Notification.objects.create(
                    ticket=ticket,
                    recipient=user,
                    message=f"New comment on ticket '{ticket.title}'."
                )
            messages.success(request, 'Comment added to the ticket.')
            return redirect('ticket_detail', ticket_id=ticket.id)
    else:
        form = ActivityForm()
    return render(request, 'tickets/add_activity.html', {'form': form, 'ticket': ticket})

