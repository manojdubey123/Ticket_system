from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Ticket, Assignment, Activity, Customer


class CustomerRegistrationForm(UserCreationForm):
    class Meta:
        model = Customer
        fields = ["first_name", "last_name", "email", "password1", "password2"]

class CustomerLoginForm(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)

class TicketForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ["title", "description", "assigned_to"]

class TicketForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ['title', 'description', 'priority']

class AssignmentForm(forms.Form):
    assigned_user = forms.ModelChoiceField(queryset=None)

    def __init__(self, *args, **kwargs):
        available_users = kwargs.pop('available_users', None)
        super().__init__(*args, **kwargs)
        if available_users:
            self.fields['assigned_user'].queryset = available_users

class UpdateStatusForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ['status']

class ActivityForm(forms.ModelForm):
    class Meta:
        model = Activity
        fields = ['comment']
