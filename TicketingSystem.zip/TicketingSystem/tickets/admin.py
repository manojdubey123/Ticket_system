from django.contrib import admin
from .models import User, Ticket, Assignment, Activity, Notification, Customer

admin.site.register(Customer)
admin.site.register(User)
admin.site.register(Ticket)
admin.site.register(Assignment)
admin.site.register(Activity)
admin.site.register(Notification)

