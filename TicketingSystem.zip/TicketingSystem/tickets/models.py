from django.db import models
from django.contrib.auth.models import AbstractUser, AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.utils import timezone

# Custom manager for Customer
class CustomerManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, password, **extra_fields)

# Custom Customer model
class Customer(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    objects = CustomerManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    # Custom reverse accessors
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='customer_set',  # Change related_name to avoid clash
        blank=True
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='customer_set',  # Change related_name to avoid clash
        blank=True
    )

    def __str__(self):
        return self.email

# Custom User model
class User(AbstractUser):
    is_admin = models.BooleanField(default=False)

    # Custom reverse accessors
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='user_set',  # Change related_name to avoid clash
        blank=True
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='user_set',  # Change related_name to avoid clash
        blank=True
    )

    def __str__(self):
        return self.username

# Ticket model remains the same as before
class Ticket(models.Model):
    PRIORITY_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
    ]

    STATUS_CHOICES = [
        ('Open', 'Open'),
        ('In Progress', 'In Progress'),
        ('Resolved', 'Resolved'),
        ('Closed', 'Closed'),
    ]

    title = models.CharField(max_length=255)
    description = models.TextField()
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='Medium')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Open')
    creator = models.ForeignKey('Customer', on_delete=models.CASCADE, related_name='created_tickets')  # Lazy reference
    assigned_to = models.ManyToManyField('Customer', related_name='assigned_tickets', blank=True)  # Lazy reference
    assigned_customer = models.ForeignKey(
        'Customer',
        on_delete=models.CASCADE,
        related_name='ticket_assigned_customer',
        null=True,
        blank=True
    ) # Changed related_name
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class Assignment(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='assignments')
    assigned_user = models.ForeignKey('Customer', on_delete=models.CASCADE, related_name='assignments')  # Lazy reference
    assigned_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.ticket.title} assigned to {self.assigned_user.username}"

class Activity(models.Model):
    ACTION_CHOICES = [
        ('status_change', 'Status Change'),
        ('comment', 'Comment'),
    ]

    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='activities')
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    comment = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, blank=True, null=True, choices=Ticket.STATUS_CHOICES)
    performed_by = models.ForeignKey('User', on_delete=models.CASCADE)  # Lazy reference to User
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Activity on {self.ticket.title} by {self.performed_by.username}"

class Notification(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='notifications')
    recipient = models.ForeignKey('Customer', on_delete=models.CASCADE, related_name='notifications')  # Lazy reference
    message = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)
    read = models.BooleanField(default=False)

    def __str__(self):
        return f"Notification for {self.recipient.username} - {self.message[:20]}"
