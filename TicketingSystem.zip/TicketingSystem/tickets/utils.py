from django.core.mail import send_mail
from django.conf import settings
from .models import Notification

def send_notification(ticket, recipient, message):
    """
    Sends a notification email to the user and creates a Notification object.
    """
    # subject = f"Notification: Ticket {ticket.title}"
    # email_message = f"Dear {recipient.username},\n\n{message}\n\nThank you,\nTicketing System"
    #
    # # Send email
    # send_mail(
    #     subject,
    #     email_message,
    #     settings.DEFAULT_FROM_EMAIL,
    #     [recipient.email],
    # )

    # Create a notification in the database
    Notification.objects.create(
        ticket=ticket,
        recipient=recipient,
        message=message
    )
