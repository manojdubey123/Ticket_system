from django.urls import path
from . import views

urlpatterns = [
path("register/", views.register, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("tickets/", views.ticket_list, name="ticket_list"),
    path('', views.ticket_list, name='ticket_list'),  # Lists all tickets
    path('create/', views.create_ticket, name='create_ticket'),
    path('<int:ticket_id>/assign/', views.assign_ticket, name='assign_ticket'),
    path('<int:ticket_id>/update_status/', views.update_status, name='update_status'),
    path('<int:ticket_id>/add_activity/', views.add_activity, name='add_activity'),
    path('<int:ticket_id>/', views.ticket_detail, name='ticket_detail'),  # Add this line
    path('tickets/all/', views.all_create_ticket_list, name='all_create_ticket_list'),
]
